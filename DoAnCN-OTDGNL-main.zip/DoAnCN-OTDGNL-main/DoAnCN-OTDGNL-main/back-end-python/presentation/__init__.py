"""Presentation layer: HTTP API."""
