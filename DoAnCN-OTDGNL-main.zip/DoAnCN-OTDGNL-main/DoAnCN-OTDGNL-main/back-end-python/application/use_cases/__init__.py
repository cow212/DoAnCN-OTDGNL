"""Application use case package."""
