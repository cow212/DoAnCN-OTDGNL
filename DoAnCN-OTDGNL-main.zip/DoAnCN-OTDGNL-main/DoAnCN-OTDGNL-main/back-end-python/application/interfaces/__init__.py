"""Application interfaces package."""
