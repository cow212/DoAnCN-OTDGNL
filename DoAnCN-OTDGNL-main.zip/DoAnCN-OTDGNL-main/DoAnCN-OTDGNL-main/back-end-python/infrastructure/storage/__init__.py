"""Infrastructure storage package."""
