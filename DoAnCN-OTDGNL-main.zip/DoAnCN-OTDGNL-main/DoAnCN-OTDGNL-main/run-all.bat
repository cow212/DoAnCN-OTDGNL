@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0giai-phong-cong.ps1"
if errorlevel 1 (
    pause
    exit /b 1
)
start "Backend - port 8000" cmd /k "back-end-python\run-server.bat"
start "Client - port 5500" cmd /k "front-end\run-client.bat"
